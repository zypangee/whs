#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

// Function to count the number of if statements in a node
int count_if(cJSON *node) {
    if (!cJSON_IsObject(node)) {
        return 0;
    }

    int if_count = 0;

    cJSON *child = cJSON_GetObjectItem(node, "iffalse");
    if (child) {
        if_count++;  // Count this "if" statement
    }

    cJSON *next_if = cJSON_GetObjectItem(node, "iftrue");
    if (next_if) {
        if_count += count_if(next_if);  // Recursively count "if" statements in the "iftrue" branch
    }

    return if_count;
}

int main() {
    // Specify the path to your JSON file
    const char *json_file_path = "dump.json";
    
    // Open the JSON file for reading
    FILE *json_file = fopen(json_file_path, "r");

    if (json_file == NULL) {
        printf("Error opening JSON file\n");
        return 1;
    }

    // Read the JSON data from the file
    fseek(json_file, 0, SEEK_END);
    long file_size = ftell(json_file);
    fseek(json_file, 0, SEEK_SET);

    char *json_data = (char *)malloc(file_size + 1);
    if (json_data == NULL) {
        fclose(json_file);
        printf("Memory allocation error\n");
        return 1;
    }

    fread(json_data, 1, file_size, json_file);
    json_data[file_size] = '\0';

    fclose(json_file);

    cJSON *root = cJSON_Parse(json_data);

    if (root == NULL) {
        printf("Error parsing JSON\n");
        free(json_data);
        return 1;
    }

    cJSON *ext = cJSON_GetObjectItem(root, "ext");
    if (!cJSON_IsArray(ext)) {
        printf("Error: 'ext' not found in JSON or is not an array\n");
        cJSON_Delete(root);
        free(json_data);
        return 1;
    }

    int function_count = cJSON_GetArraySize(ext);
    printf("Number of Functions: %d\n", function_count);

    for (int i = 0; i < function_count; i++) {
        cJSON *function = cJSON_GetArrayItem(ext, i);
        cJSON *decl = cJSON_GetObjectItem(function, "decl");

        cJSON *decl_type = cJSON_GetObjectItem(decl, "type");
        cJSON *decl_name = cJSON_GetObjectItem(decl, "name");
        cJSON *return_type = cJSON_GetObjectItem(decl_type, "type"); // Get the return type
        printf("Function %d: Return Type: %s, Name: %s\n", i + 1,
               cJSON_IsString(return_type) ? cJSON_GetStringValue(return_type) : "N/A",
               cJSON_IsString(decl_name) ? cJSON_GetStringValue(decl_name) : "N/A");

        cJSON *param_list = cJSON_GetObjectItem(decl_type, "args");
        if (param_list && cJSON_IsArray(param_list)) {
            int param_count = cJSON_GetArraySize(param_list);
            printf("Parameters:\n");
            for (int j = 0; j < param_count; j++) {
                cJSON *param = cJSON_GetArrayItem(param_list, j);
                cJSON *param_name = cJSON_GetObjectItem(param, "name");
                cJSON *param_type = cJSON_GetObjectItem(param, "type");
                printf("  Parameter %d: Type: %s, Name: %s\n", j + 1,
                       cJSON_IsString(param_type) ? cJSON_GetStringValue(param_type) : "N/A",
                       cJSON_IsString(param_name) ? cJSON_GetStringValue(param_name) : "N/A");
            }
        } else {
            printf("No Parameters\n");
        }

        cJSON *body = cJSON_GetObjectItem(function, "body");
        int if_count = count_if(body);
        printf("Number of If Statements: %d\n", if_count);
    }

    cJSON_Delete(root);
    free(json_data);
    return 0;
}
